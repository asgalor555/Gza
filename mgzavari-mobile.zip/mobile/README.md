# MGZAVARI Rent — Mobile (Capacitor)

არსებული React ვებ-აპი, შეფუთული Capacitor-ით → Android / iOS აპლიკაცია.

## წინაპირობა (შენს კომპიუტერზე)
- Node.js 18+
- Android-ისთვის: **Android Studio**
- iOS-ისთვის: **Xcode** (მხოლოდ macOS)

## გაშვება ბრაუზერში (სწრაფი ტესტი)
```bash
npm install
npm run dev          # http://localhost:5173
```

## ნატიურ აპად აწყობა
```bash
npm install
npm run build                 # ქმნის dist/-ს

npx cap add android           # და/ან: npx cap add ios   (მხოლოდ macOS)
npx cap sync                  # აკოპირებს build-ს ნატიურ პროექტში
npx cap open android          # ხსნის Android Studio-ს  (ან: npx cap open ios)
```
Android Studio / Xcode-დან აეშენებ და გაუშვებ ემულატორზე ან რეალურ მოწყობილობაზე,
ხოლო მერე — მაღაზიაში ასატვირთად.

## კონფიგი
- `capacitor.config.ts`: `appId: ge.mgzavari.rent`, `appName: MGZAVARI Rent`
- მუქი status bar / splash უკვე მორგებულია (`src/main.jsx`).
- notch / home-indicator უსაფრთხო ზონები — `src/mobile.css`.

## კამერა და GPS
ამჟამად აპი იყენებს `<input capture>`-ს (ფოტო) და `navigator.geolocation`-ს — ორივე
მუშაობს WebView-ში. უფრო ნატიური შეგრძნებისთვის შეგიძლია გადახვიდე
`@capacitor/camera` / `@capacitor/geolocation`-ზე (plugin-ები უკვე `package.json`-შია).
Android-ზე ნებართვები ემატება `AndroidManifest.xml`-ში, iOS-ზე — `Info.plist`-ში
(`NSCameraUsageDescription`, `NSLocationWhenInUseUsageDescription`).

## დარჩენილი (ადამიანის ქმედება)
- Apple Developer (~$99/წ) + Google Play Console (~$25)
- აპის icon, splash, სახელი, მაღაზიის აღწერა
- backend-ის რეალური URL (ახლა აპი in-memory დემო მონაცემებზეა)
