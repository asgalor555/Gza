import React, { useState, useMemo, useRef, useEffect } from "react";
import {
  Search, Car, Clock, User, LayoutDashboard, CalendarDays, Wallet, MapPin,
  Calendar, Users, Fuel, Cog, Briefcase, Star, Shield, Check, ChevronRight,
  ArrowLeft, Plus, X, CreditCard, BadgeCheck, Snowflake, Camera, Bell,
  TrendingUp, Pause, Play, Trash2, Banknote, PenLine, RotateCcw, AlertTriangle,
  ShieldCheck, Settings, Heart, Gauge, MessageCircle,
} from "lucide-react";

/* ============================================================
   MGZAVARI RENT — ერთიანი აპლიკაცია
   კლიენტი · მფლობელი · დაზიანების შემოწმება — ერთ დიზაინ-სისტემაში
   ============================================================ */

/* ---------- დიზაინ-ტოკენები (ერთი წყარო) ---------- */
const gel = (n) => `${Math.round(n).toLocaleString("en-US")} ₾`;
const MONTHS = ["იან", "თებ", "მარ", "აპრ", "მაი", "ივნ", "ივლ", "აგვ", "სექ", "ოქტ", "ნოე", "დეკ"];
const today = new Date(); today.setHours(0, 0, 0, 0);
const plus = (n) => { const d = new Date(today); d.setDate(today.getDate() + n); return d; };
const key = (d) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
const fmt = (d) => `${d.getDate()} ${MONTHS[d.getMonth()]}`;
const daysBetween = (a, b) => Math.max(1, Math.round((b - a) / 86400000));

/* ---------- მონაცემები (ერთი ავტოპარკი) ---------- */
const CARS = [
  { id: "c1", name: "Toyota RAV4", type: "suv", cls: "SUV", year: 2023, seats: 5, bags: 4, trans: "ავტომატიკა", fuel: "ჰიბრიდი", rate: 195, deposit: 1000, rating: 4.9, trips: 174, color: "#2c2f33", host: "ნინო ქ.", loc: "თბილისი, აეროპორტი", owned: true, status: "active", booked: [plus(5), plus(6), plus(7)], blocked: [] },
  { id: "c2", name: "Hyundai Accent", type: "sedan", cls: "ეკონომი", year: 2022, seats: 5, bags: 2, trans: "ავტომატიკა", fuel: "ბენზინი", rate: 90, deposit: 500, rating: 4.8, trips: 142, color: "#dfe4e0", host: "ნინო ქ.", loc: "თბილისი, ვაკე", owned: true, status: "active", booked: [plus(10), plus(11)], blocked: [plus(2)] },
  { id: "c3", name: "VW Golf", type: "hatch", cls: "სტანდარტი", year: 2021, seats: 5, bags: 2, trans: "მექანიკა", fuel: "ბენზინი", rate: 110, deposit: 600, rating: 4.7, trips: 96, color: "#c8453a", host: "ქართ რენტი", loc: "თბილისი, ცენტრი", owned: false, status: "active", booked: [], blocked: [] },
  { id: "c4", name: "Mercedes E-Class", type: "lux", cls: "ბიზნეს", year: 2023, seats: 5, bags: 3, trans: "ავტომატიკა", fuel: "ბენზინი", rate: 330, deposit: 1800, rating: 4.9, trips: 64, color: "#1b1d20", host: "ნინო ქ.", loc: "თბილისი, ცენტრი", owned: true, status: "paused", booked: [], blocked: [] },
  { id: "c5", name: "Tesla Model 3", type: "lux", cls: "ელექტრო", year: 2024, seats: 5, bags: 2, trans: "ავტომატიკა", fuel: "ელექტრო", rate: 280, deposit: 1500, rating: 4.95, trips: 51, color: "#b81d2c", host: "Lux Drive", loc: "თბილისი, საბურთალო", owned: false, status: "active", booked: [], blocked: [] },
  { id: "c6", name: "Land Cruiser Prado", type: "suv", cls: "პრემიუმ SUV", year: 2022, seats: 7, bags: 5, trans: "ავტომატიკა", fuel: "დიზელი", rate: 360, deposit: 2000, rating: 5.0, trips: 88, color: "#e8e2d2", host: "ავტო ჰაბი", loc: "თბილისი, ვაკე", owned: false, status: "active", booked: [], blocked: [] },
];
const FILTERS = ["ყველა", "ეკონომი", "სტანდარტი", "SUV", "პრემიუმ SUV", "ბიზნეს", "ელექტრო"];
const INSURANCE = [
  { id: "basic", name: "ბაზისური (CDW)", perDay: 0, desc: "სტანდარტული დაფარვა", icon: Shield },
  { id: "full", name: "სრული დაფარვა", perDay: 28, desc: "შემცირებული ფრანშიზა", icon: Shield },
  { id: "zero", name: "ნულოვანი ფრანშიზა", perDay: 48, desc: "სრული დაცვა", icon: BadgeCheck },
];
const ADDONS = [
  { id: "driver", name: "დამატებითი მძღოლი", perDay: 15, icon: Users },
  { id: "seat", name: "ბავშვის სავარძელი", perDay: 8, icon: Shield },
  { id: "gps", name: "GPS ნავიგატორი", perDay: 6, icon: MapPin },
  { id: "miles", name: "ულიმიტო კმ", perDay: 20, icon: Gauge },
];
const MONTHLY = [{ m: "იან", v: 1850 }, { m: "თებ", v: 2100 }, { m: "მარ", v: 1950 }, { m: "აპრ", v: 2680 }, { m: "მაი", v: 3120 }, { m: "ივნ", v: 2840 }];
const REVIEWS = [
  { name: "ლევან გ.", rating: 5, date: "მაისი", text: "იდეალური მანქანა, მფლობელი ძალიან თავაზიანი. ნამდვილად გავიმეორებ." },
  { name: "თამარ ბ.", rating: 5, date: "აპრილი", text: "სუფთა, გამართული, ჩაბარება სწრაფად მოხდა. გირჩევთ." },
  { name: "ნიკა ფ.", rating: 4, date: "მარტი", text: "კარგი გამოცდილება, ოდნავ დააგვიანდა აღებაზე, თორემ ყველაფერი რიგზე იყო." },
];
const RATING_BREAKDOWN = [{ s: 5, p: 86 }, { s: 4, p: 10 }, { s: 3, p: 3 }, { s: 2, p: 1 }, { s: 1, p: 0 }];

function quote(car, days, insId, addonIds) {
  const base = car.rate * days;
  const dp = days >= 30 ? 0.2 : days >= 7 ? 0.1 : 0;
  const discount = base * dp;
  const ins = (INSURANCE.find((i) => i.id === insId)?.perDay || 0) * days;
  const addonsTotal = addonIds.reduce((s, id) => s + (ADDONS.find((a) => a.id === id)?.perDay || 0) * days, 0);
  return { base, discount, dp, ins, addonsTotal, total: base - discount + ins + addonsTotal, deposit: car.deposit };
}

/* ---------- შემოწმების ლოგიკა ---------- */
const DMG_TYPES = [{ id: "scratch", name: "ნაკაწრი", base: 60 }, { id: "dent", name: "ჩაჭდევა", base: 140 }, { id: "crack", name: "ბზარი", base: 200 }, { id: "chip", name: "ქვის კვალი", base: 40 }, { id: "glass", name: "მინა", base: 280 }];
const DMG_SEV = [{ id: "light", name: "მსუბუქი", mult: 0.6 }, { id: "medium", name: "საშუალო", mult: 1.0 }, { id: "heavy", name: "მძიმე", mult: 1.8 }];
const PHOTO_ANGLES = [{ id: "front", name: "წინა" }, { id: "back", name: "უკანა" }, { id: "left", name: "მარცხენა" }, { id: "right", name: "მარჯვენა" }, { id: "interior", name: "სალონი" }, { id: "odo", name: "სპიდომეტრი" }];
const repairCost = (t, s) => Math.round((DMG_TYPES.find((x) => x.id === t)?.base || 0) * (DMG_SEV.find((x) => x.id === s)?.mult || 1));

/* ---------- საერთო კომპონენტები ---------- */
function CarArt({ color, type, small }) {
  const roof = { sedan: "M58,46 L78,30 Q82,26 90,26 L128,26 Q136,26 142,32 L162,46 Z", hatch: "M58,46 L76,30 Q80,26 88,26 L150,26 Q160,28 166,46 Z", suv: "M56,46 L60,24 Q61,21 66,21 L150,21 Q156,21 158,26 L160,46 Z", lux: "M56,46 L80,31 Q85,27 94,27 L126,27 Q135,27 140,31 L164,46 Z" }[type] || "M58,46 L80,30 L142,30 L162,46 Z";
  return (
    <svg viewBox="0 0 220 96" style={{ width: "100%", height: small ? 64 : 140 }}>
      <ellipse cx="110" cy="86" rx="84" ry="6" fill="#000" opacity="0.25" />
      <path d={roof} fill={color} opacity="0.92" />
      <rect x="22" y="44" width="176" height="30" rx="13" fill={color} />
      <rect x="22" y="56" width="176" height="18" rx="9" fill="#000" opacity="0.16" />
      <path d={roof} fill="#0c0f0c" opacity="0.55" transform="scale(0.86) translate(18,5)" />
      <rect x="190" y="50" width="8" height="7" rx="2" fill="#fff5cc" />
      {[68, 152].map((cx) => <g key={cx}><circle cx={cx} cy="74" r="14" fill="#15181a" /><circle cx={cx} cy="74" r="6" fill="#3a4046" /></g>)}
    </svg>
  );
}
function MiniMap() {
  return (
    <div className="minimap">
      <svg viewBox="0 0 100 60" preserveAspectRatio="xMidYMid slice" style={{ width: "100%", height: "100%" }}>
        <rect width="100" height="60" fill="#11150f" />
        <g stroke="#222a24" strokeWidth="0.6">
          {[12, 24, 36, 48].map((p) => <line key={"h" + p} x1="0" y1={p} x2="100" y2={p} />)}
          {[16, 32, 48, 64, 80].map((p) => <line key={"v" + p} x1={p} y1="0" x2={p} y2="60" />)}
        </g>
        <line x1="0" y1="22" x2="100" y2="38" stroke="#2c3a2e" strokeWidth="2" strokeLinecap="round" />
        <line x1="55" y1="0" x2="48" y2="60" stroke="#2c3a2e" strokeWidth="2" />
        <g transform="translate(50,32)">
          <circle r="9" fill="#c8ff2e" opacity="0.18"><animate attributeName="r" values="6;11;6" dur="2.4s" repeatCount="indefinite" /></circle>
          <path d="M0,-7 C4.5,-7 4.5,-1 0,3 C-4.5,-1 -4.5,-7 0,-7 Z" fill="#c8ff2e" />
          <circle cy="-3.4" r="1.7" fill="#0c0f0c" />
        </g>
      </svg>
    </div>
  );
}
function Modal({ children, title, onClose, danger }) {
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className={"modal" + (danger ? " danger" : "")} onClick={(e) => e.stopPropagation()}>
        <div className="modal-head"><span>{title}</span><button onClick={onClose}><X size={18} /></button></div>
        {children}
      </div>
    </div>
  );
}
function EarningsChart({ data }) {
  const max = Math.max(...data.map((d) => d.v));
  return (
    <div className="chart">{data.map((d, i) => (
      <div key={i} className="bar-col"><div className="bar-track"><div className="cbar" style={{ height: `${(d.v / max) * 100}%` }} /></div><span className="bar-lbl">{d.m}</span></div>
    ))}</div>
  );
}
function CalendarRange({ start, end, onChange, onClose }) {
  const [sel, setSel] = useState({ s: start, e: end });
  const days = Array.from({ length: 35 }, (_, i) => plus(i));
  const pick = (d) => { if (!sel.s || sel.e) setSel({ s: d, e: null }); else if (d > sel.s) setSel({ s: sel.s, e: d }); else setSel({ s: d, e: null }); };
  const inR = (d) => sel.s && sel.e && d > sel.s && d < sel.e;
  return (
    <Modal title="აირჩიე თარიღები" onClose={onClose}>
      <div className="cal">{days.map((d, i) => {
        const edge = (sel.s && d.getTime() === sel.s.getTime()) || (sel.e && d.getTime() === sel.e.getTime());
        return <button key={i} className={"cd" + (edge ? " edge" : "") + (inR(d) ? " mid" : "")} onClick={() => pick(d)}><span className="cd-d">{d.getDate()}</span><span className="cd-m">{MONTHS[d.getMonth()]}</span></button>;
      })}</div>
      <button className="cta full" disabled={!sel.s || !sel.e} onClick={() => { onChange(sel.s, sel.e); onClose(); }}>
        {sel.s && sel.e ? `დადასტურება · ${daysBetween(sel.s, sel.e)} დღე` : "აირჩიე დაბრუნების დღეც"}
      </button>
    </Modal>
  );
}

/* ============================================================
   APP SHELL
   ============================================================ */
export default function App() {
  const [mode, setMode] = useState("renter");
  return (
    <div className="root">
      <style>{CSS}</style>
      <div className="phone">
        <div className="appbar">
          <span className="brand"><span className="tri">▲</span> MGZAVARI</span>
          <div className="mode-switch">
            <button className={mode === "renter" ? "on" : ""} onClick={() => setMode("renter")}>ქირაობა</button>
            <button className={mode === "host" ? "on" : ""} onClick={() => setMode("host")}>მფლობელი</button>
          </div>
        </div>
        {mode === "renter" ? <Renter /> : <Host />}
      </div>
    </div>
  );
}

/* ============================================================
   RENTER
   ============================================================ */
function Renter() {
  const [tab, setTab] = useState("explore");
  const [screen, setScreen] = useState(null); // {type:'detail'|'book', car}
  const [filter, setFilter] = useState("ყველა");
  const [start, setStart] = useState(today);
  const [end, setEnd] = useState(plus(3));
  const [calOpen, setCalOpen] = useState(false);
  const [bookings, setBookings] = useState([]);
  const [favs, setFavs] = useState([]);
  const days = daysBetween(start, end);
  const list = CARS.filter((c) => filter === "ყველა" || c.cls === filter);

  const addBooking = (car, data) => { setBookings((b) => [{ id: "b" + Date.now(), car, days, start, end, ...data }, ...b]); setScreen(null); setTab("trips"); };
  const toggleFav = (id) => setFavs((f) => f.includes(id) ? f.filter((x) => x !== id) : [...f, id]);

  if (screen?.type === "detail") return <Detail car={screen.car} days={days} start={start} end={end} onBack={() => setScreen(null)} onBook={() => setScreen({ type: "book", car: screen.car })} onDates={() => setCalOpen(true)} onOpenCar={(c) => setScreen({ type: "detail", car: c })} cal={calOpen && <CalendarRange start={start} end={end} onChange={(s, e) => { setStart(s); setEnd(e); }} onClose={() => setCalOpen(false)} />} />;
  if (screen?.type === "book") return <Booking car={screen.car} days={days} onBack={() => setScreen({ type: "detail", car: screen.car })} onDone={(data) => addBooking(screen.car, data)} />;

  return (
    <div className="screen">
      {tab === "explore" && (
        <>
          <div className="sub-hdr">
            <button className="searchbox-lg" onClick={() => setCalOpen(true)}>
              <MapPin size={16} /> <span>თბილისი</span><span className="vline" />
              <Calendar size={16} /> <span>{fmt(start)}–{fmt(end)} · {days} დღე</span>
            </button>
          </div>
          <div className="filters">{FILTERS.map((f) => <button key={f} className={"fchip" + (filter === f ? " on" : "")} onClick={() => setFilter(f)}>{f}</button>)}</div>
          <div className="scroll">
            <p className="count">{list.length} ხელმისაწვდომი მანქანა</p>
            {list.map((c, i) => (
              <div key={c.id} className="ccard" style={{ animationDelay: (i * 0.05) + "s" }} onClick={() => setScreen({ type: "detail", car: c })}>
                <div className="ccard-art">
                  <CarArt color={c.color} type={c.type} small />
                  <span className="cls-tag">{c.cls}</span>
                  <button className={"fav" + (favs.includes(c.id) ? " on" : "")} onClick={(e) => { e.stopPropagation(); toggleFav(c.id); }}>
                    <Heart size={16} fill={favs.includes(c.id) ? "#c8ff2e" : "none"} />
                  </button>
                </div>
                <div className="ccard-body">
                  <div className="row-between"><span className="cname">{c.name}</span><span className="rate">{gel(c.rate)}<small>/დღე</small></span></div>
                  <div className="specs"><span><Users size={13} /> {c.seats}</span><span><Cog size={13} /> {c.trans === "ავტომატიკა" ? "ავტო" : "მექ"}</span><span><Fuel size={13} /> {c.fuel}</span></div>
                  <div className="foot"><span className="rating"><Star size={12} fill="#c8ff2e" /> {c.rating} · {c.trips}</span><span className="tmini">{gel(c.rate * days)} / {days} დღე</span></div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
      {tab === "trips" && <Trips bookings={bookings} />}
      {tab === "profile" && <Profile />}

      <BottomNav tabs={[["explore", Search, "მთავარი"], ["trips", Clock, "ჯავშნები", bookings.length], ["profile", User, "პროფილი"]]} tab={tab} setTab={setTab} />
      {calOpen && tab === "explore" && <CalendarRange start={start} end={end} onChange={(s, e) => { setStart(s); setEnd(e); }} onClose={() => setCalOpen(false)} />}
    </div>
  );
}

function Detail({ car, days, start, end, onBack, onBook, onDates, onOpenCar, cal }) {
  const specs = [[Users, `${car.seats} ადგილი`], [Briefcase, `${car.bags} ჩანთა`], [Cog, car.trans], [Fuel, car.fuel], [Calendar, `${car.year}`], [Snowflake, "კონდიცონერი"]];
  const similar = CARS.filter((c) => c.id !== car.id && c.type === car.type);
  const sim = (similar.length ? similar : CARS.filter((c) => c.id !== car.id)).slice(0, 5);
  return (
    <div className="screen">
      <div className="detail-hero">
        <button className="fab" onClick={onBack}><ArrowLeft size={20} /></button>
        <span className="cls-tag big">{car.cls}</span>
        <CarArt color={car.color} type={car.type} />
      </div>
      <div className="scroll">
        <div className="row-between">
          <div><h2>{car.name}</h2>
            <div className="qchips">
              <span className="qchip"><Star size={12} fill="#c8ff2e" /> {car.rating}</span>
              <span className="qchip">{car.trips} ქირაობა</span>
              <span className="qchip"><MapPin size={12} /> {car.loc.split(",").pop().trim()}</span>
            </div>
          </div>
          <span className="rate big">{gel(car.rate)}<small>/დღე</small></span>
        </div>

        <div className="specs-grid">{specs.map(([Ic, l], i) => <div key={i} className="spec"><Ic size={16} /> {l}</div>)}</div>

        <h3 className="section-t">რა შედის</h3>
        <div className="feat-list">{["უფასო გაუქმება 48სთ-ით ადრე", "100 კმ/დღე ფასში", "24/7 საგზაო დახმარება", "სრული ავზი — დააბრუნე სავსე"].map((f) => <div key={f} className="feat"><Check size={15} color="#c8ff2e" /> {f}</div>)}</div>

        <h3 className="section-t">მფლობელი</h3>
        <div className="host-row"><div className="av">{car.host[0]}</div><div className="hgrow"><div className="bold">{car.host} <BadgeCheck size={14} color="#c8ff2e" style={{ verticalAlign: "-2px" }} /></div><div className="mut"><Clock size={11} /> პასუხობს ~10 წთ-ში · {car.trips}+ გაქირავება</div></div><button className="msg-btn"><MessageCircle size={18} /></button></div>

        <h3 className="section-t">აღების ადგილი</h3>
        <MiniMap />
        <div className="loc-row"><MapPin size={15} color="#c8ff2e" /> {car.loc}</div>

        <h3 className="section-t">შეფასებები</h3>
        <div className="rev-head">
          <div className="rev-score"><div className="rev-num">{car.rating}</div><div className="rev-stars">{[1, 2, 3, 4, 5].map((s) => <Star key={s} size={12} fill={s <= Math.round(car.rating) ? "#c8ff2e" : "none"} color="#c8ff2e" />)}</div><div className="mut">{car.trips} შეფასება</div></div>
          <div className="rbars">{RATING_BREAKDOWN.map((b) => <div key={b.s} className="rbar"><span>{b.s}</span><div className="rtrack"><div className="rfill" style={{ width: b.p + "%" }} /></div></div>)}</div>
        </div>
        {REVIEWS.map((r, i) => <div key={i} className="rev"><div className="rev-top"><div className="rev-av">{r.name[0]}</div><div><div className="bold">{r.name}</div><div className="mut">{r.date}</div></div><div className="rev-rs">{[1, 2, 3, 4, 5].map((s) => <Star key={s} size={11} fill={s <= r.rating ? "#c8ff2e" : "none"} color="#c8ff2e" />)}</div></div><p className="rev-text">{r.text}</p></div>)}

        <h3 className="section-t">მსგავსი მანქანები</h3>
        <div className="sim-scroll">{sim.map((c) => <button key={c.id} className="sim" onClick={() => onOpenCar(c)}><div className="sim-art"><CarArt color={c.color} type={c.type} small /></div><div className="sim-n">{c.name}</div><div className="sim-p">{gel(c.rate)}<small>/დღე</small></div></button>)}</div>

        <button className="dates-row" style={{ marginTop: 20 }} onClick={onDates}><Calendar size={16} /><span>{fmt(start)}–{fmt(end)}</span><span className="mut">{days} დღე</span><ChevronRight size={16} style={{ marginLeft: "auto" }} /></button>
      </div>
      <div className="bar"><div><span className="mut">{days} დღეზე</span><div className="bigp">{gel(car.rate * days)}</div></div><button className="cta" onClick={onBook}>დაჯავშნა</button></div>
      {cal}
    </div>
  );
}

function Booking({ car, days, onBack, onDone }) {
  const [step, setStep] = useState(0);
  const [ins, setIns] = useState("basic");
  const [addons, setAddons] = useState([]);
  const [pay, setPay] = useState("card");
  const [lic, setLic] = useState(false);
  const q = useMemo(() => quote(car, days, ins, addons), [ins, addons, days]);
  const tog = (id) => setAddons((a) => a.includes(id) ? a.filter((x) => x !== id) : [...a, id]);
  return (
    <div className="screen">
      <div className="flow-hdr"><button className="fab sm" onClick={() => step === 0 ? onBack() : setStep(step - 1)}><ArrowLeft size={18} /></button><Steps n={4} step={step} /></div>
      <div className="scroll">
        {step === 0 && <>
          <h2>დაზღვევა</h2>
          {INSURANCE.map((i) => <button key={i.id} className={"opt" + (ins === i.id ? " on" : "")} onClick={() => setIns(i.id)}><i.icon size={20} /><div className="opt-t"><div className="bold">{i.name}</div><div className="mut">{i.desc}</div></div><span className="opt-p">{i.perDay ? `+${i.perDay} ₾` : "შედის"}</span></button>)}
          <h2 style={{ marginTop: 18 }}>დამატებები</h2>
          {ADDONS.map((a) => <button key={a.id} className={"opt" + (addons.includes(a.id) ? " on" : "")} onClick={() => tog(a.id)}><a.icon size={20} /><div className="opt-t"><div className="bold">{a.name}</div></div><span className="opt-p">+{a.perDay} ₾</span><span className="ck">{addons.includes(a.id) ? <Check size={15} /> : <Plus size={15} />}</span></button>)}
        </>}
        {step === 1 && <>
          <h2>მძღოლის ვერიფიკაცია</h2><p className="mut" style={{ marginBottom: 16 }}>გაქირავებამდე საჭიროა მართვის მოწმობის დადასტურება.</p>
          <Field label="სრული სახელი" ph="გიორგი მაისურაძე" /><Field label="ასაკი (21+)" ph="25" />
          <button className={"upload" + (lic ? " ok" : "")} onClick={() => setLic(true)}>{lic ? <><BadgeCheck size={20} /> მოწმობა ატვირთულია</> : <><Plus size={20} /> ატვირთე მართვის მოწმობა</>}</button>
        </>}
        {step === 2 && <>
          <h2>გადახდა</h2>
          <div className="pay-row"><button className={"pay" + (pay === "card" ? " on" : "")} onClick={() => setPay("card")}><CreditCard size={16} /> ბარათი</button><button className={"pay" + (pay === "cash" ? " on" : "")} onClick={() => setPay("cash")}>💵 ნაღდი</button></div>
          <div className="quote">
            <Q l={`${gel(car.rate)} × ${days} დღე`} v={gel(q.base)} />
            {q.discount > 0 && <Q l={`ფასდაკლება −${Math.round(q.dp * 100)}%`} v={`−${gel(q.discount)}`} disc />}
            {q.ins > 0 && <Q l="დაზღვევა" v={gel(q.ins)} />}
            {q.addonsTotal > 0 && <Q l="დამატებები" v={gel(q.addonsTotal)} />}
            <Q l="სულ" v={gel(q.total)} total />
          </div>
          <div className="dep-note"><Shield size={16} color="#ffcf4d" /><span>დეპოზიტი {gel(q.deposit)} დაიბლოკება (pre-auth) და დაბრუნდება ჩაბარების შემდეგ.</span></div>
        </>}
        {step === 3 && <div className="done"><div className="done-ic"><Check size={40} /></div><h2>ჯავშანი დადასტურდა! 🎉</h2><p className="mut">{car.name} · {days} დღე</p><div className="code"><span>აღების კოდი</span><b>{Math.random().toString(36).slice(2, 8).toUpperCase()}</b></div></div>}
      </div>
      <div className="bar">{step < 3
        ? <button className="cta full" disabled={step === 1 && !lic} onClick={() => setStep(step + 1)}>{step === 2 ? `გადახდა ${gel(q.total)}` : "გაგრძელება"}</button>
        : <button className="cta full" onClick={() => onDone({ ins, addons, total: q.total, deposit: q.deposit })}>ჩემი ჯავშნები</button>}</div>
    </div>
  );
}

function Trips({ bookings }) {
  return (
    <div className="screen-inner"><div className="page-hdr"><h1>ჩემი ჯავშნები</h1></div>
      <div className="scroll">
        {bookings.length === 0 && <div className="empty"><Clock size={40} color="#3a423b" /><p>ჯერ ჯავშანი არ გაქვს</p></div>}
        {bookings.map((b) => (
          <div key={b.id} className="ccard static"><div className="ccard-art sm"><CarArt color={b.car.color} type={b.car.type} small /></div>
            <div className="ccard-body"><div className="row-between"><span className="cname">{b.car.name}</span><span className="status">დადასტურებული</span></div><div className="mut">{fmt(b.start)}–{fmt(b.end)} · {b.days} დღე</div><div className="foot"><span className="mut">{b.car.loc}</span><span className="tmini">{gel(b.total)}</span></div></div></div>
        ))}
      </div>
    </div>
  );
}

function Profile() {
  const items = [[CreditCard, "გადახდის მეთოდები"], [BadgeCheck, "მართვის მოწმობა", "დადასტურებული"], [Shield, "უსაფრთხოება"], [Settings, "პარამეტრები"]];
  return (
    <div className="screen-inner"><div className="page-hdr"><h1>პროფილი</h1></div>
      <div className="scroll">
        <div className="prof-top"><div className="av lg">გ</div><div><div className="bold" style={{ fontSize: 17 }}>გიორგი მაისურაძე</div><span className="rating"><Star size={13} fill="#c8ff2e" /> 4.9 · 12 ქირაობა</span></div></div>
        {items.map(([Ic, l, tag], i) => <button key={i} className="prof-row"><Ic size={18} /><span>{l}</span>{tag && <span className="verif">{tag}</span>}<ChevronRight size={16} color="#8a948c" style={{ marginLeft: "auto" }} /></button>)}
      </div>
    </div>
  );
}

/* ============================================================
   HOST
   ============================================================ */
function Host() {
  const [tab, setTab] = useState("dash");
  const [overlay, setOverlay] = useState(null);
  const [cars, setCars] = useState(CARS.filter((c) => c.owned));
  const [requests, setRequests] = useState([
    { id: "r1", carId: "c1", renter: "ლაშა ბ.", rating: 4.9, start: plus(14), end: plus(17), days: 3, total: 585, msg: "სამუშაო მოგზაურობა" },
    { id: "r2", carId: "c2", renter: "ანა კ.", rating: 5.0, start: plus(20), end: plus(27), days: 7, total: 567, msg: "კახეთში" },
  ]);
  const [upcoming, setUpcoming] = useState([{ id: "u1", carId: "c1", renter: "გიორგი მ.", start: plus(5), end: plus(8), days: 3, total: 585, phase: "pickup" }]);
  const [active, setActive] = useState([{ id: "a1", carId: "c2", renter: "დავით კ.", start: plus(-2), end: plus(1), days: 3, total: 270, deposit: 500, phase: "return" }]);
  const [earnings, setEarnings] = useState(2840);

  const approve = (req) => { setRequests((r) => r.filter((x) => x.id !== req.id)); setUpcoming((u) => [{ id: "u" + Date.now(), ...req, phase: "pickup" }, ...u]); setEarnings((e) => e + req.total); };
  const decline = (id) => setRequests((r) => r.filter((x) => x.id !== id));
  const toggleStatus = (id) => setCars((cs) => cs.map((c) => c.id === id ? { ...c, status: c.status === "active" ? "paused" : "active" } : c));
  const toggleBlock = (id, d) => setCars((cs) => cs.map((c) => { if (c.id !== id) return c; const k = key(d), has = c.blocked.some((b) => key(b) === k); return { ...c, blocked: has ? c.blocked.filter((b) => key(b) !== k) : [...c.blocked, d] }; }));
  const updateRate = (id, dl) => setCars((cs) => cs.map((c) => c.id === id ? { ...c, rate: Math.max(20, c.rate + dl) } : c));
  const addCar = (car) => { setCars((cs) => [{ ...car, id: "c" + Date.now(), owned: true, booked: [], blocked: [], rating: 5.0, trips: 0 }, ...cs]); setOverlay(null); setTab("cars"); };

  const manageCar = overlay?.type === "manage" ? cars.find((c) => c.id === overlay.id) : null;
  const carName = (id) => CARS.find((c) => c.id === id)?.name || "";

  if (overlay?.type === "inspect") return <Inspection mode={overlay.mode} car={CARS.find(c=>c.id===overlay.carId)} onExit={() => setOverlay(null)} />;
  if (manageCar) return <CarManage car={manageCar} upcoming={upcoming.filter((u) => u.carId === manageCar.id)} onBack={() => setOverlay(null)} onToggleBlock={(d) => toggleBlock(manageCar.id, d)} onRate={(dl) => updateRate(manageCar.id, dl)} onStatus={() => toggleStatus(manageCar.id)} />;
  if (overlay?.type === "add") return <AddCar onBack={() => setOverlay(null)} onSave={addCar} />;

  return (
    <div className="screen">
      {tab === "dash" && <HostDash cars={cars} requests={requests} earnings={earnings} onApprove={approve} onDecline={decline} onSeeAll={() => setTab("bookings")} carName={carName} />}
      {tab === "cars" && <HostCars cars={cars} onManage={(id) => setOverlay({ type: "manage", id })} onAdd={() => setOverlay({ type: "add" })} onToggle={toggleStatus} />}
      {tab === "bookings" && <HostBookings requests={requests} upcoming={upcoming} active={active} carName={carName} onApprove={approve} onDecline={decline} onInspect={(mode, carId) => setOverlay({ type: "inspect", mode, carId })} />}
      {tab === "earnings" && <HostEarnings earnings={earnings} />}
      <BottomNav tabs={[["dash", LayoutDashboard, "მთავარი"], ["cars", Car, "მანქანები"], ["bookings", CalendarDays, "ჯავშნები", requests.length], ["earnings", Wallet, "ფინანსები"]]} tab={tab} setTab={setTab} />
    </div>
  );
}

function HostDash({ cars, requests, earnings, onApprove, onDecline, onSeeAll, carName }) {
  const active = cars.filter((c) => c.status === "active").length;
  const avg = (cars.reduce((s, c) => s + c.rating, 0) / cars.length).toFixed(2);
  return (
    <div className="screen-inner">
      <div className="dash-hdr"><div><span className="mut">გამარჯობა, ნინო 👋</span></div><button className="bell"><Bell size={20} /><span className="bdot" /></button></div>
      <div className="scroll">
        <div className="kpi big"><span className="mut">ამ თვის შემოსავალი</span><div className="kpi-v"><CountUp value={earnings} fmt={gel} /></div><span className="up"><TrendingUp size={13} /> +12%</span></div>
        <div className="kpi-row"><div className="kpi"><span className="mut">აქტიური</span><div className="kpi-v sm">{active}/{cars.length}</div></div><div className="kpi"><span className="mut">რეიტინგი</span><div className="kpi-v sm">★ {avg}</div></div></div>
        <div className="block"><div className="block-h"><h3>შემოსავალი</h3><span className="mut">6 თვე</span></div><EarningsChart data={MONTHLY} /></div>
        <div className="block"><div className="block-h"><h3>ახალი მოთხოვნები</h3>{requests.length > 0 && <button className="link" onClick={onSeeAll}>ყველა</button>}</div>
          {requests.length === 0 ? <p className="empty sm">მოთხოვნა არ არის</p> : requests.slice(0, 2).map((r) => <Req key={r.id} r={r} carName={carName} onApprove={onApprove} onDecline={onDecline} />)}
        </div>
      </div>
    </div>
  );
}
function Req({ r, carName, onApprove, onDecline }) {
  return (
    <div className="req">
      <div className="row-between"><div className="renter"><div className="av sm">{r.renter[0]}</div><div><div className="bold">{r.renter}</div><div className="mut star"><Star size={11} fill="#c8ff2e" /> {r.rating}</div></div></div><span className="req-total">{gel(r.total)}</span></div>
      <div className="req-info">{carName(r.carId)} · {fmt(r.start)}–{fmt(r.end)} · {r.days} დღე</div>
      {r.msg && <div className="req-msg">„{r.msg}"</div>}
      <div className="req-act"><button className="decline" onClick={() => onDecline(r.id)}><X size={16} /> უარი</button><button className="approve" onClick={() => onApprove(r)}><Check size={16} /> დადასტურება</button></div>
    </div>
  );
}
function HostCars({ cars, onManage, onAdd, onToggle }) {
  return (
    <div className="screen-inner"><div className="page-hdr"><h1>ჩემი მანქანები</h1><button className="add-btn" onClick={onAdd}><Plus size={18} /> დამატება</button></div>
      <div className="scroll">{cars.map((c) => (
        <div key={c.id} className={"mcar" + (c.status === "paused" ? " paused" : "")}>
          <div className="mcar-art"><CarArt color={c.color} type={c.type} small /></div>
          <div className="mcar-body" onClick={() => onManage(c.id)}><div className="row-between"><span className="cname">{c.name}</span><span className="rate">{gel(c.rate)}<small>/დღე</small></span></div><div className="mut">{c.loc}</div><div className="foot"><span className="rating"><Star size={12} fill="#c8ff2e" /> {c.rating} · {c.trips}</span><ChevronRight size={16} color="#8a948c" /></div></div>
          <button className={"stat" + (c.status === "active" ? " on" : "")} onClick={() => onToggle(c.id)}>{c.status === "active" ? <><Play size={13} /> აქტიური</> : <><Pause size={13} /> შეჩერებული</>}</button>
        </div>
      ))}</div>
    </div>
  );
}
function CarManage({ car, upcoming, onBack, onToggleBlock, onRate, onStatus }) {
  return (
    <div className="screen">
      <div className="detail-hero"><button className="fab" onClick={onBack}><ArrowLeft size={20} /></button><CarArt color={car.color} type={car.type} /></div>
      <div className="scroll">
        <div className="row-between" style={{ marginBottom: 16 }}><div><h2>{car.name}</h2><span className="rating"><Star size={13} fill="#c8ff2e" /> {car.rating} · {car.trips}</span></div><button className={"stat" + (car.status === "active" ? " on" : "")} onClick={onStatus}>{car.status === "active" ? "აქტიური" : "შეჩერებული"}</button></div>
        <div className="block"><h3>დღიური ფასი</h3><div className="rate-edit"><button onClick={() => onRate(-5)}>−</button><div className="rate-big">{gel(car.rate)}<small>/დღე</small></div><button onClick={() => onRate(5)}><Plus size={18} /></button></div><p className="mut center">დეპოზიტი: {gel(car.deposit)}</p></div>
        <div className="block"><h3>ხელმისაწვდომობა</h3>
          <div className="legend"><span><i className="lg avail" /> ხელმისაწვდომი</span><span><i className="lg blocked" /> დაბლოკილი</span><span><i className="lg booked" /> დაჯავშნული</span></div>
          <p className="mut" style={{ marginBottom: 10 }}>დააჭირე დღეს დასაბლოკად</p>
          <AvailCal booked={car.booked} blocked={car.blocked} onToggle={onToggleBlock} />
        </div>
        <div className="block"><h3>მომავალი ჯავშნები</h3>{upcoming.length === 0 ? <p className="empty sm">ჯავშანი არ აქვს</p> : upcoming.map((u) => <div key={u.id} className="bline"><Car size={18} /><div><div className="bold">{u.renter}</div><div className="mut">{fmt(u.start)}–{fmt(u.end)} · {u.days} დღე</div></div><span className="tmini">{gel(u.total)}</span></div>)}</div>
        <button className="danger"><Trash2 size={16} /> განცხადების წაშლა</button>
      </div>
    </div>
  );
}
function AvailCal({ booked, blocked, onToggle }) {
  const days = Array.from({ length: 35 }, (_, i) => plus(i));
  const bs = new Set(booked.map(key)), bl = new Set(blocked.map(key));
  return <div className="acal">{days.map((d, i) => { const k = key(d), bk = bs.has(k), bd = bl.has(k); return <button key={i} disabled={bk} className={"acd" + (bk ? " booked" : "") + (bd ? " blocked" : "")} onClick={() => !bk && onToggle(d)}><span>{d.getDate()}</span><small>{MONTHS[d.getMonth()]}</small></button>; })}</div>;
}
function HostBookings({ requests, upcoming, active, carName, onApprove, onDecline, onInspect }) {
  const [seg, setSeg] = useState("req");
  return (
    <div className="screen-inner"><div className="page-hdr"><h1>ჯავშნები</h1></div>
      <div className="seg">{[["req", `მოთხოვნები (${requests.length})`], ["active", "აქტიური"], ["up", "მომავალი"]].map(([k, l]) => <button key={k} className={seg === k ? "on" : ""} onClick={() => setSeg(k)}>{l}</button>)}</div>
      <div className="scroll">
        {seg === "req" && (requests.length === 0 ? <p className="empty">მოთხოვნა არ არის</p> : requests.map((r) => <div key={r.id} className="block"><Req r={r} carName={carName} onApprove={onApprove} onDecline={onDecline} /></div>))}
        {seg === "active" && active.map((a) => (
          <div key={a.id} className="bline col"><div className="bline-top"><Car size={18} /><div><div className="bold">{a.renter}</div><div className="mut">{carName(a.carId)} · მიმდინარე</div></div><span className="tmini">{gel(a.total)}</span></div>
            <button className="inspect-cta" onClick={() => onInspect("return", a.carId)}><RotateCcw size={15} /> ჩაბარების შემოწმება</button></div>
        ))}
        {seg === "up" && upcoming.map((u) => (
          <div key={u.id} className="bline col"><div className="bline-top"><Car size={18} /><div><div className="bold">{u.renter}</div><div className="mut">{carName(u.carId)} · {fmt(u.start)}–{fmt(u.end)}</div></div><span className="tmini">{gel(u.total)}</span></div>
            <button className="inspect-cta" onClick={() => onInspect("pickup", u.carId)}><Car size={15} /> აღების შემოწმება</button></div>
        ))}
      </div>
    </div>
  );
}
function HostEarnings({ earnings }) {
  const tx = [{ d: "8 ივნ", w: "გიორგი მ.", c: "Toyota RAV4", a: 585 }, { d: "5 ივნ", w: "გადარიცხვა ბანკში", c: "TBC ****4471", a: -1840 }, { d: "1 ივნ", w: "დავით კ.", c: "Toyota RAV4", a: 585 }];
  return (
    <div className="screen-inner"><div className="page-hdr"><h1>ფინანსები</h1></div>
      <div className="scroll">
        <div className="balance"><span className="mut">ხელმისაწვდომი</span><div className="bal-v"><CountUp value={earnings} fmt={gel} /></div><button className="payout"><Banknote size={16} /> გატანა ბანკში</button><span className="mut">შემდეგი გადარიცხვა: 15 ივნ</span></div>
        <div className="block"><div className="block-h"><h3>შემოსავალი</h3><span className="mut">6 თვე</span></div><EarningsChart data={MONTHLY} /></div>
        <div className="block"><h3>ტრანზაქციები</h3>{tx.map((t, i) => <div key={i} className="tx"><div className={"tx-ic" + (t.a < 0 ? " out" : "")}>{t.a < 0 ? <Banknote size={16} /> : <Car size={16} />}</div><div className="tx-i"><div className="bold">{t.w}</div><div className="mut">{t.c} · {t.d}</div></div><span className={"tx-a" + (t.a < 0 ? " out" : "")}>{t.a > 0 ? "+" : ""}{gel(t.a)}</span></div>)}</div>
      </div>
    </div>
  );
}
function AddCar({ onBack, onSave }) {
  const [step, setStep] = useState(0);
  const [f, setF] = useState({ name: "", type: "sedan", cls: "სტანდარტი", year: 2023, seats: 5, bags: 3, trans: "ავტომატიკა", fuel: "ბენზინი", rate: 120, deposit: 700, color: "#5b8def", loc: "თბილისი", host: "ნინო ქ." });
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const colors = ["#5b8def", "#dfe4e0", "#c8453a", "#2c2f33", "#1b1d20", "#e8e2d2", "#b81d2c"];
  return (
    <div className="screen">
      <div className="flow-hdr"><button className="fab sm" onClick={() => step === 0 ? onBack() : setStep(step - 1)}><ArrowLeft size={18} /></button><Steps n={3} step={step} /></div>
      <div className="scroll">
        {step === 0 && <>
          <h2>მანქანის ინფორმაცია</h2>
          <div className="add-art"><CarArt color={f.color} type={f.type} /></div>
          <div className="colors">{colors.map((c) => <button key={c} className={"sw" + (f.color === c ? " on" : "")} style={{ background: c }} onClick={() => set("color", c)} />)}</div>
          <Field label="მარკა და მოდელი" ph="Toyota Corolla" val={f.name} onChange={(v) => set("name", v)} />
          <div className="grid2"><FieldSel label="ტიპი" val={f.type} onChange={(v) => set("type", v)} opts={[["sedan", "სედანი"], ["suv", "ჯიპი"], ["hatch", "ჰეჩბეკი"], ["lux", "პრემიუმი"]]} /><Field label="წელი" ph="2023" val={f.year} onChange={(v) => set("year", v)} num /></div>
        </>}
        {step === 1 && <>
          <h2>სპეციფიკაცია</h2>
          <div className="grid2"><Field label="ადგილები" val={f.seats} onChange={(v) => set("seats", v)} num /><FieldSel label="კოლოფი" val={f.trans} onChange={(v) => set("trans", v)} opts={[["ავტომატიკა", "ავტომატიკა"], ["მექანიკა", "მექანიკა"]]} /></div>
          <FieldSel label="საწვავი" val={f.fuel} onChange={(v) => set("fuel", v)} opts={[["ბენზინი", "ბენზინი"], ["დიზელი", "დიზელი"], ["ჰიბრიდი", "ჰიბრიდი"], ["ელექტრო", "ელექტრო"]]} />
          <Field label="ლოკაცია" ph="თბილისი, ვაკე" val={f.loc} onChange={(v) => set("loc", v)} />
          <div className="photo-box"><Camera size={24} /><span>დაამატე ფოტოები (მინ. 3)</span></div>
        </>}
        {step === 2 && <>
          <h2>ფასი</h2>
          <p className="mut" style={{ marginBottom: 8 }}>დღიური ტარიფი</p>
          <div className="rate-edit"><button onClick={() => set("rate", Math.max(20, f.rate - 5))}>−</button><div className="rate-big">{gel(f.rate)}</div><button onClick={() => set("rate", f.rate + 5)}><Plus size={18} /></button></div>
          <Field label="დეპოზიტი (₾)" val={f.deposit} onChange={(v) => set("deposit", v)} num />
          <div className="est"><span className="mut">სავარაუდო თვიური შემოსავალი (15 დღე)</span><div className="est-v">{gel(f.rate * 15 * 0.85)}</div></div>
        </>}
      </div>
      <div className="bar"><button className="cta full" disabled={step === 0 && !f.name} onClick={() => step === 2 ? onSave({ ...f, cls: f.type === "suv" ? "SUV" : f.type === "lux" ? "ბიზნეს" : "სტანდარტი", status: "active" }) : setStep(step + 1)}>{step === 2 ? "გამოქვეყნება" : "გაგრძელება"}</button></div>
    </div>
  );
}

/* ============================================================
   INSPECTION (მფლობელის ნაწილში)
   ============================================================ */
function Inspection({ mode, car, onExit }) {
  const isReturn = mode === "return";
  const EXISTING = [{ id: "e1", x: 22, y: 30, type: "scratch", sev: "light", existing: true }, { id: "e2", x: 74, y: 62, type: "chip", sev: "light", existing: true }];
  const [step, setStep] = useState(0);
  const [photos, setPhotos] = useState({});
  const [damages, setDamages] = useState(isReturn ? [...EXISTING] : []);
  const [fuel, setFuel] = useState(isReturn ? 3 : 8);
  const [odo, setOdo] = useState(isReturn ? "48 920" : "48 540");
  const [signed, setSigned] = useState(false);
  const deposit = car?.deposit || 1000;
  const newD = damages.filter((d) => !d.existing);
  const pc = Object.keys(photos).length;
  const can = step === 0 ? pc >= 4 : step === 3 ? signed : true;
  const names = ["ფოტოები", "სქემა", "მაჩვენებლები", "ხელმოწერა"];
  return (
    <div className="screen">
      <div className="flow-hdr"><button className="fab sm" onClick={() => step === 0 ? onExit() : setStep(step - 1)}><ArrowLeft size={18} /></button><span className="flow-title">{isReturn ? "ჩაბარების" : "აღების"} შემოწმება</span><Steps n={4} step={step} w={70} /></div>
      <div className="scroll">
        {step < 4 && <p className="step-name">{step + 1}/4 · {names[step]}</p>}
        {step === 0 && <PhotoStep photos={photos} setPhotos={setPhotos} />}
        {step === 1 && <DiagramStep damages={damages} setDamages={setDamages} isReturn={isReturn} />}
        {step === 2 && <MeterStep odo={odo} setOdo={setOdo} fuel={fuel} setFuel={setFuel} />}
        {step === 3 && <SignStep signed={signed} setSigned={setSigned} newD={newD} />}
        {step === 4 && <InspDone isReturn={isReturn} newD={newD} deposit={deposit} onExit={onExit} />}
      </div>
      {step < 4 && <div className="bar"><button className="cta full" disabled={!can} onClick={() => setStep(step + 1)}>{step === 0 && pc < 4 ? `გადაიღე მინ. 4 (${pc}/6)` : step === 3 ? (isReturn ? "დასრულება + დეპოზიტი" : "დასრულება") : "გაგრძელება"}</button></div>}
    </div>
  );
}
function PhotoStep({ photos, setPhotos }) {
  const h = (id, e) => { const f = e.target.files?.[0]; if (f) setPhotos((p) => ({ ...p, [id]: URL.createObjectURL(f) })); };
  return <><p className="mut" style={{ marginBottom: 14 }}>გადაიღე მანქანა ყველა მხრიდან.</p>
    <div className="pgrid">{PHOTO_ANGLES.map((s) => <label key={s.id} className={"pslot" + (photos[s.id] ? " filled" : "")}><input type="file" accept="image/*" capture="environment" hidden onChange={(e) => h(s.id, e)} />{photos[s.id] ? <><img src={photos[s.id]} alt="" /><span className="pck"><Check size={14} /></span></> : <><Camera size={22} /><span>{s.name}</span></>}</label>)}</div></>;
}
function DiagramStep({ damages, setDamages, isReturn }) {
  const [edit, setEdit] = useState(null);
  const ref = useRef(null);
  const add = (e) => { const r = ref.current.getBoundingClientRect(); const x = ((e.clientX - r.left) / r.width) * 100, y = ((e.clientY - r.top) / r.height) * 100; if (x < 8 || x > 92 || y < 3 || y > 97) return; const d = { id: "d" + Date.now(), x, y, type: "scratch", sev: "light", existing: false }; setDamages((a) => [...a, d]); setEdit(d); };
  const upd = (id, p) => setDamages((a) => a.map((d) => d.id === id ? { ...d, ...p } : d));
  const rm = (id) => { setDamages((a) => a.filter((d) => d.id !== id)); setEdit(null); };
  return <><p className="mut" style={{ marginBottom: 12 }}>დააჭირე მანქანას დაზიანების მოსანიშნად.{isReturn && " ნაცრისფერი = არსებული."}</p>
    <div className="diagram" ref={ref} onClick={add}><CarTop />{damages.map((d, i) => <button key={d.id} className={"mark " + (d.existing ? "old" : "new")} style={{ left: d.x + "%", top: d.y + "%" }} onClick={(e) => { e.stopPropagation(); setEdit(d); }}>{i + 1}</button>)}</div>
    {isReturn && <div className="dleg"><span><i className="lg old" /> არსებული ({damages.filter(d=>d.existing).length})</span><span><i className="lg new" /> ახალი ({damages.filter(d=>!d.existing).length})</span></div>}
    <div className="dlist">{damages.length === 0 ? <p className="empty sm">დაზიანება არ არის — იდეალურია ✓</p> : damages.map((d, i) => <button key={d.id} className="ditem" onClick={() => setEdit(d)}><span className={"dn " + (d.existing ? "old" : "new")}>{i + 1}</span><span style={{ flex: 1 }}>{DMG_TYPES.find((t) => t.id === d.type)?.name} · {DMG_SEV.find((s) => s.id === d.sev)?.name}</span>{d.existing ? <span className="mut">არსებული</span> : <span className="dcost">{gel(repairCost(d.type, d.sev))}</span>}</button>)}</div>
    {edit && <DmgEditor d={edit} onUpd={(p) => { upd(edit.id, p); setEdit({ ...edit, ...p }); }} onRm={() => rm(edit.id)} onClose={() => setEdit(null)} />}
  </>;
}
function CarTop() {
  return <svg viewBox="0 0 200 360" className="cartop">{[[18, 70], [164, 70], [18, 250], [164, 250]].map(([x, y], i) => <rect key={i} x={x} y={y} width="18" height="42" rx="6" fill="#15181a" />)}<rect x="16" y="118" width="14" height="18" rx="4" fill="#2c2f33" /><rect x="170" y="118" width="14" height="18" rx="4" fill="#2c2f33" /><rect x="30" y="18" width="140" height="324" rx="46" fill="#23282a" stroke="#363c3e" strokeWidth="2" /><path d="M44,70 Q100,52 156,70 L156,96 Q100,84 44,96 Z" fill="#1b1f21" /><path d="M52,100 Q100,92 148,100 L138,140 Q100,134 62,140 Z" fill="#0c0f0c" opacity="0.7" /><rect x="58" y="146" width="84" height="120" rx="14" fill="#1b1f21" /><path d="M62,272 Q100,278 138,272 L148,304 Q100,312 52,304 Z" fill="#0c0f0c" opacity="0.7" /></svg>;
}
function DmgEditor({ d, onUpd, onRm, onClose }) {
  const h = (e) => { if (e.target.files?.[0]) onUpd({ photo: URL.createObjectURL(e.target.files[0]) }); };
  return <Modal title="დაზიანების დეტალები" onClose={onClose}>
    {d.existing && <div className="exist"><AlertTriangle size={14} /> აღებისას დაფიქსირებული</div>}
    <p className="field-l">ტიპი</p><div className="chips">{DMG_TYPES.map((t) => <button key={t.id} className={"chip" + (d.type === t.id ? " on" : "")} disabled={d.existing} onClick={() => onUpd({ type: t.id })}>{t.name}</button>)}</div>
    <p className="field-l">სიმძიმე</p><div className="chips">{DMG_SEV.map((s) => <button key={s.id} className={"chip" + (d.sev === s.id ? " on" : "")} disabled={d.existing} onClick={() => onUpd({ sev: s.id })}>{s.name}</button>)}</div>
    {!d.existing && <><label className="dphoto"><input type="file" accept="image/*" capture="environment" hidden onChange={h} />{d.photo ? <img src={d.photo} alt="" /> : <><Camera size={18} /> დაამატე ფოტო</>}</label><div className="cost-row"><span>სავარაუდო შეკეთება</span><b>{gel(repairCost(d.type, d.sev))}</b></div><button className="danger" onClick={onRm}><Trash2 size={15} /> წაშლა</button></>}
  </Modal>;
}
function MeterStep({ odo, setOdo, fuel, setFuel }) {
  return <>
    <div className="block"><div className="mhead"><Gauge size={18} color="#c8ff2e" /> სპიდომეტრი (კმ)</div><input className="odo" value={odo} onChange={(e) => setOdo(e.target.value)} /></div>
    <div className="block"><div className="mhead"><Fuel size={18} color="#c8ff2e" /> საწვავი</div><div className="fbar">{Array.from({ length: 8 }, (_, i) => <button key={i} className={"fseg" + (i < fuel ? " on" : "")} onClick={() => setFuel(i + 1)} />)}</div><div className="flabels"><span>ცარიელი</span><span>{Math.round((fuel / 8) * 100)}%</span><span>სავსე</span></div></div>
    <div className="block"><div className="mhead"><ShieldCheck size={18} color="#c8ff2e" /> სალონი</div><div className="chips">{["სუფთა", "ნორმალური", "დასასუფთავებელი"].map((s, i) => <button key={s} className={"chip" + (i === 0 ? " on" : "")}>{s}</button>)}</div></div>
  </>;
}
function SignStep({ signed, setSigned, newD }) {
  const cv = useRef(null), drw = useRef(false);
  useEffect(() => { const c = cv.current; const x = c.getContext("2d"); c.width = c.offsetWidth * 2; c.height = c.offsetHeight * 2; x.scale(2, 2); x.strokeStyle = "#c8ff2e"; x.lineWidth = 2.5; x.lineCap = "round"; }, []);
  const pos = (e) => { const r = cv.current.getBoundingClientRect(); const t = e.touches?.[0]; return { x: (t ? t.clientX : e.clientX) - r.left, y: (t ? t.clientY : e.clientY) - r.top }; };
  const st = (e) => { e.preventDefault(); drw.current = true; const x = cv.current.getContext("2d"); const p = pos(e); x.beginPath(); x.moveTo(p.x, p.y); };
  const mv = (e) => { if (!drw.current) return; e.preventDefault(); const x = cv.current.getContext("2d"); const p = pos(e); x.lineTo(p.x, p.y); x.stroke(); setSigned(true); };
  const en = () => { drw.current = false; };
  const clr = () => { const c = cv.current; c.getContext("2d").clearRect(0, 0, c.width, c.height); setSigned(false); };
  return <>
    <div className="sum"><div className="row-between"><span>ფოტოები</span><b>დაფიქსირდა ✓</b></div><div className="row-between"><span>ახალი დაზიანება</span><b>{newD.length}</b></div>{newD.length > 0 && <div className="row-between"><span>სავარაუდო ხარჯი</span><b style={{ color: "#ffcf4d" }}>{gel(newD.reduce((s, d) => s + repairCost(d.type, d.sev), 0))}</b></div>}</div>
    <p className="field-l">ხელმოწერა</p>
    <div className="sign-wrap"><canvas ref={cv} className="sign" onMouseDown={st} onMouseMove={mv} onMouseUp={en} onMouseLeave={en} onTouchStart={st} onTouchMove={mv} onTouchEnd={en} />{!signed && <span className="sign-ph"><PenLine size={16} /> მოაწერე აქ</span>}<button className="sign-clr" onClick={clr}><RotateCcw size={14} /></button></div>
  </>;
}
function InspDone({ isReturn, newD, deposit, onExit }) {
  const cost = newD.reduce((s, d) => s + repairCost(d.type, d.sev), 0);
  const charge = Math.min(cost, deposit), refund = deposit - charge;
  if (!isReturn) return <div className="done"><div className="done-ic"><Check size={40} /></div><h2>აღების შემოწმება დასრულდა</h2><p className="mut">მდგომარეობა დაფიქსირდა.</p><button className="cta full" style={{ marginTop: 24 }} onClick={onExit}>დასრულება</button></div>;
  return <div className="done"><div className={"done-ic" + (charge > 0 ? " warn" : "")}>{charge > 0 ? <AlertTriangle size={36} /> : <Check size={40} />}</div><h2>{charge > 0 ? "ახალი დაზიანება" : "იდეალურ მდგომარეობაში"}</h2>
    <div className="depres"><div className="dr"><span>დაბლოკილი დეპოზიტი</span><b>{gel(deposit)}</b></div>{newD.map((d, i) => <div key={i} className="dr sub"><span>{DMG_TYPES.find((t) => t.id === d.type)?.name}</span><span className="neg">−{gel(repairCost(d.type, d.sev))}</span></div>)}{charge > 0 && <div className="dr"><span>ჩამოიჭრება</span><b className="neg">−{gel(charge)}</b></div>}<div className="dr total"><span>უბრუნდება</span><b className="pos">{gel(refund)}</b></div></div>
    <button className="cta full" style={{ marginTop: 20 }} onClick={onExit}>დასრულება</button></div>;
}

/* ---------- მცირე საერთო ---------- */
function BottomNav({ tabs, tab, setTab }) {
  return <nav className="tabbar">{tabs.map(([k, Ic, l, badge]) => <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k)}><Ic size={20} /><span>{l}</span>{badge > 0 && <span className="tbadge">{badge}</span>}</button>)}</nav>;
}
function Steps({ n, step, w }) { return <div className="steps" style={w ? { width: w } : undefined}>{Array.from({ length: n }, (_, s) => <span key={s} className={"sdot" + (s <= step ? " on" : "")} />)}</div>; }
function Field({ label, ph, val, onChange, num }) { return <div className="vfield"><span>{label}</span><input placeholder={ph} value={val ?? ""} type={num ? "number" : "text"} onChange={(e) => onChange && onChange(num ? +e.target.value : e.target.value)} /></div>; }
function FieldSel({ label, val, onChange, opts }) { return <div className="vfield"><span>{label}</span><select value={val} onChange={(e) => onChange(e.target.value)}>{opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div>; }
function CountUp({ value, fmt }) {
  const [n, setN] = useState(0);
  const prev = useRef(0);
  useEffect(() => {
    const from = prev.current, to = value; prev.current = value;
    if (from === to) { setN(to); return; }
    let raf, start; const dur = 650;
    const tick = (t) => { if (!start) start = t; const p = Math.min(1, (t - start) / dur); const e = 1 - Math.pow(1 - p, 3); setN(from + (to - from) * e); if (p < 1) raf = requestAnimationFrame(tick); else setN(to); };
    raf = requestAnimationFrame(tick); return () => cancelAnimationFrame(raf);
  }, [value]);
  return <>{fmt ? fmt(n) : Math.round(n)}</>;
}
function Q({ l, v, disc, total }) { return <div className={"qrow" + (disc ? " disc" : "") + (total ? " total" : "")}><span>{l}</span><span>{v}</span></div>; }

/* ============================================================ */
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Noto+Sans+Georgian:wght@400;500;600;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent;}
.root{ --bg:#0c0f0c; --card:#171c18; --card2:#1e241f; --line:#2a322c; --txt:#f1f5f0; --mut:#8a948c;
  --acc:#c8ff2e; --accd:#1a2110; --warn:#ffcf4d; --red:#ff6b6b;
  min-height:100vh; background:#000; display:flex; justify-content:center; font-family:'Noto Sans Georgian',sans-serif; color:var(--txt); }
.phone{ position:relative; width:100%; max-width:440px; min-height:100vh; background:var(--bg); display:flex; flex-direction:column; overflow:hidden; }

/* appbar + mode switch (ერთიანი ზედა ზოლი) */
.appbar{ display:flex; align-items:center; justify-content:space-between; padding:14px 16px; border-bottom:1px solid var(--line); }
.brand{ font-family:'Syne'; font-weight:800; letter-spacing:.5px; font-size:18px; display:flex; align-items:center; gap:6px; }
.tri{ color:var(--acc); }
.mode-switch{ display:flex; background:var(--card2); border:1px solid var(--line); border-radius:11px; padding:3px; }
.mode-switch button{ background:none; border:none; color:var(--mut); padding:7px 14px; border-radius:8px; font-family:inherit; font-size:13px; font-weight:600; cursor:pointer; }
.mode-switch button.on{ background:var(--acc); color:#0c0f0c; }

.screen{ flex:1; display:flex; flex-direction:column; overflow:hidden; }
.screen-inner{ flex:1; display:flex; flex-direction:column; overflow:hidden; }
.scroll{ flex:1; overflow-y:auto; padding:16px; }
.mut{ color:var(--mut); font-size:13px; } .center{ text-align:center; }
.bold{ font-weight:700; } .row-between{ display:flex; align-items:flex-start; justify-content:space-between; gap:8px; }

.sub-hdr{ padding:14px 16px 0; }
.searchbox-lg{ width:100%; display:flex; align-items:center; gap:8px; background:var(--card2); border:1px solid var(--line); padding:14px; border-radius:14px; color:var(--txt); font-family:inherit; font-size:13px; font-weight:600; cursor:pointer; }
.vline{ width:1px; height:18px; background:var(--line); margin:0 4px; }
.filters{ display:flex; gap:8px; overflow-x:auto; padding:14px 16px; }
.fchip{ flex-shrink:0; background:var(--card2); border:1px solid var(--line); color:var(--mut); padding:9px 15px; border-radius:20px; font-family:inherit; font-size:13px; font-weight:600; cursor:pointer; }
.fchip.on{ background:var(--acc); color:#0c0f0c; border-color:var(--acc); }
.count{ color:var(--mut); font-size:13px; margin-bottom:12px; }

.ccard{ background:var(--card); border:1px solid var(--line); border-radius:18px; overflow:hidden; margin-bottom:14px; cursor:pointer; transition:.15s; }
.ccard:active{ transform:scale(.99); } .ccard.static{ display:flex; cursor:default; }
.ccard-art{ position:relative; padding:14px 18px; display:grid; place-items:center; background:linear-gradient(135deg,#1b211c,#12150f); }
.ccard-art.sm{ width:128px; flex-shrink:0; padding:10px; }
.cls-tag{ position:absolute; top:10px; left:12px; background:rgba(12,15,12,.7); border:1px solid var(--line); color:var(--acc); font-size:11px; font-weight:700; padding:4px 9px; border-radius:8px; }
.cls-tag.big{ top:auto; bottom:14px; }
.fav{ position:absolute; top:10px; right:12px; width:34px; height:34px; border-radius:50%; background:rgba(12,15,12,.7); border:1px solid var(--line); color:var(--txt); display:grid; place-items:center; cursor:pointer; }
.fav.on{ color:var(--acc); }
.ccard-body{ padding:14px; flex:1; }
.cname{ font-weight:700; font-size:16px; }
.rate{ font-family:'Syne'; font-weight:800; color:var(--acc); font-size:18px; white-space:nowrap; } .rate small{ color:var(--mut); font-size:11px; } .rate.big{ font-size:22px; }
.specs{ display:flex; gap:14px; margin:10px 0; color:var(--mut); font-size:13px; } .specs span{ display:flex; align-items:center; gap:5px; }
.foot{ display:flex; align-items:center; justify-content:space-between; padding-top:10px; border-top:1px solid var(--line); }
.rating{ display:flex; align-items:center; gap:5px; color:var(--acc); font-size:12px; }
.tmini{ font-weight:700; font-size:13px; } .status{ background:var(--accd); color:var(--acc); font-size:11px; font-weight:700; padding:4px 9px; border-radius:8px; }
.empty{ text-align:center; color:var(--mut); padding:50px 0; display:flex; flex-direction:column; align-items:center; gap:12px; } .empty.sm{ padding:18px; font-size:13px; }

.detail-hero{ position:relative; background:linear-gradient(135deg,#1b211c,#0e120d); padding:30px 20px 22px; }
.fab{ position:absolute; top:16px; left:16px; width:40px; height:40px; border-radius:50%; background:rgba(12,15,12,.7); border:1px solid var(--line); color:var(--txt); display:grid; place-items:center; cursor:pointer; z-index:2; }
.fab.sm{ position:static; width:36px; height:36px; }
h2{ font-size:21px; margin-bottom:4px; }
.specs-grid{ display:grid; grid-template-columns:1fr 1fr; gap:10px; margin:18px 0; }
.spec{ display:flex; align-items:center; gap:9px; background:var(--card2); border:1px solid var(--line); padding:13px; border-radius:12px; font-size:14px; } .spec svg{ color:var(--acc); }
.host-row{ display:flex; align-items:center; gap:12px; background:var(--card2); border:1px solid var(--line); border-radius:14px; padding:13px; margin-bottom:14px; }
.av{ width:44px; height:44px; border-radius:50%; background:var(--acc); color:#0c0f0c; display:grid; place-items:center; font-family:'Syne'; font-weight:800; font-size:18px; flex-shrink:0; }
.av.sm{ width:38px; height:38px; font-size:16px; } .av.lg{ width:60px; height:60px; font-size:24px; }
.dates-row{ width:100%; display:flex; align-items:center; gap:10px; background:var(--card2); border:1px solid var(--line); border-radius:14px; padding:14px; color:var(--txt); font-family:inherit; font-size:14px; font-weight:600; cursor:pointer; margin-bottom:14px; } .dates-row svg{ color:var(--acc); }
.feat-list{ display:flex; flex-direction:column; gap:10px; } .feat{ display:flex; align-items:center; gap:9px; font-size:14px; }

.bar{ display:flex; align-items:center; justify-content:space-between; gap:14px; background:var(--card); border-top:1px solid var(--line); padding:14px 16px; }
.bigp{ font-family:'Syne'; font-weight:800; font-size:24px; }
.cta{ background:var(--acc); color:#0c0f0c; border:none; padding:15px 26px; border-radius:14px; font-family:'Syne'; font-weight:800; font-size:15px; cursor:pointer; white-space:nowrap; } .cta.full{ flex:1; } .cta:disabled{ background:var(--card2); color:var(--mut); } .cta:active{ transform:scale(.98); }

.flow-hdr{ display:flex; align-items:center; gap:12px; padding:16px; border-bottom:1px solid var(--line); }
.flow-title{ font-weight:700; font-size:15px; flex:1; }
.steps{ display:flex; gap:6px; flex:1; } .sdot{ flex:1; height:4px; border-radius:2px; background:var(--line); } .sdot.on{ background:var(--acc); }
.step-name{ font-size:12px; color:var(--acc); font-weight:600; margin-bottom:14px; }

.opt{ width:100%; display:flex; align-items:center; gap:13px; background:var(--card2); border:1px solid var(--line); border-radius:14px; padding:14px; margin-bottom:10px; cursor:pointer; font-family:inherit; color:var(--txt); text-align:left; } .opt.on{ border-color:var(--acc); background:var(--accd); } .opt svg{ color:var(--acc); flex-shrink:0; }
.opt-t{ flex:1; } .opt-p{ font-family:'Syne'; font-weight:700; color:var(--acc); font-size:13px; white-space:nowrap; }
.ck{ width:26px; height:26px; border-radius:8px; background:var(--bg); border:1px solid var(--line); display:grid; place-items:center; color:var(--acc); }
.vfield{ margin-bottom:14px; } .vfield span{ display:block; font-size:13px; color:var(--mut); margin-bottom:6px; }
.vfield input,.vfield select{ width:100%; background:var(--card2); border:1px solid var(--line); color:var(--txt); padding:13px; border-radius:12px; font-family:inherit; font-size:15px; outline:none; }
.grid2{ display:grid; grid-template-columns:1fr 1fr; gap:12px; }
.upload{ width:100%; display:flex; align-items:center; justify-content:center; gap:10px; background:var(--card2); border:1px dashed var(--line); color:var(--txt); padding:18px; border-radius:14px; font-family:inherit; font-size:14px; font-weight:600; cursor:pointer; } .upload.ok{ border-style:solid; border-color:var(--acc); color:var(--acc); } .upload svg{ color:var(--acc); }
.pay-row{ display:flex; gap:10px; margin-bottom:16px; }
.pay{ flex:1; display:flex; align-items:center; justify-content:center; gap:8px; background:var(--card2); border:1px solid var(--line); color:var(--mut); padding:14px; border-radius:12px; font-family:inherit; font-size:13px; font-weight:600; cursor:pointer; } .pay.on{ border-color:var(--acc); color:var(--txt); background:var(--accd); }
.quote{ background:var(--card2); border:1px solid var(--line); border-radius:14px; padding:16px; margin-bottom:14px; }
.qrow{ display:flex; justify-content:space-between; padding:7px 0; font-size:14px; } .qrow.disc{ color:var(--acc); } .qrow.total{ border-top:1px solid var(--line); margin-top:6px; padding-top:12px; font-family:'Syne'; font-weight:800; font-size:18px; }
.dep-note{ display:flex; gap:10px; background:#2a230d; border:1px solid #4a3d12; border-radius:12px; padding:13px; font-size:12px; color:#ffe0a0; line-height:1.5; }
.done{ text-align:center; padding:30px 0; } .done-ic{ width:80px; height:80px; border-radius:50%; background:var(--acc); color:#0c0f0c; display:grid; place-items:center; margin:0 auto 18px; } .done-ic.warn{ background:var(--warn); }
.code{ background:var(--card2); border:1px solid var(--line); border-radius:14px; padding:16px; margin-top:18px; display:flex; flex-direction:column; gap:6px; } .code b{ font-family:'Syne'; font-size:26px; color:var(--acc); letter-spacing:3px; }

.cal{ display:grid; grid-template-columns:repeat(7,1fr); gap:6px; margin-bottom:16px; }
.cd{ aspect-ratio:1; background:var(--card2); border:1px solid var(--line); border-radius:10px; color:var(--txt); display:flex; flex-direction:column; align-items:center; justify-content:center; cursor:pointer; font-family:inherit; } .cd-d{ font-weight:700; font-size:15px; } .cd-m{ font-size:9px; color:var(--mut); } .cd.mid{ background:var(--accd); border-color:#3a4a18; } .cd.edge{ background:var(--acc); border-color:var(--acc); color:#0c0f0c; } .cd.edge .cd-m{ color:#0c0f0c; }

.page-hdr{ display:flex; align-items:center; justify-content:space-between; padding:18px 16px; border-bottom:1px solid var(--line); } .page-hdr h1{ font-size:22px; font-family:'Syne'; font-weight:800; }
.dash-hdr{ display:flex; align-items:flex-start; justify-content:space-between; padding:18px 16px 4px; }
.bell{ position:relative; background:var(--card2); border:1px solid var(--line); color:var(--txt); width:42px; height:42px; border-radius:13px; display:grid; place-items:center; cursor:pointer; } .bdot{ position:absolute; top:9px; right:11px; width:8px; height:8px; border-radius:50%; background:var(--acc); }
.kpi{ background:var(--card); border:1px solid var(--line); border-radius:16px; padding:16px; } .kpi.big{ margin-bottom:10px; background:linear-gradient(135deg,#1d2417,#141811); } .kpi-row{ display:flex; gap:10px; margin-bottom:14px; } .kpi-row .kpi{ flex:1; }
.kpi-v{ font-family:'Syne'; font-weight:800; font-size:30px; margin:6px 0 4px; } .kpi-v.sm{ font-size:22px; } .up{ font-size:12px; color:var(--acc); display:flex; align-items:center; gap:5px; }
.block{ background:var(--card); border:1px solid var(--line); border-radius:16px; padding:16px; margin-bottom:14px; } .block-h{ display:flex; align-items:center; justify-content:space-between; margin-bottom:14px; } .block h3{ font-size:15px; } .link{ background:none; border:none; color:var(--acc); font-family:inherit; font-weight:600; font-size:13px; cursor:pointer; }
.chart{ display:flex; align-items:flex-end; gap:10px; height:120px; } .bar-col{ flex:1; display:flex; flex-direction:column; align-items:center; gap:8px; height:100%; } .bar-track{ flex:1; width:100%; display:flex; align-items:flex-end; } .cbar{ width:100%; background:linear-gradient(180deg,var(--acc),#7aa015); border-radius:7px 7px 0 0; min-height:8px; transform-origin:bottom; animation:growBar .6s ease both; } .bar-lbl{ font-size:11px; color:var(--mut); }
.req{ margin-bottom:4px; } .renter{ display:flex; align-items:center; gap:10px; } .star{ display:flex; align-items:center; gap:4px; margin-top:2px; }
.req-total{ font-family:'Syne'; font-weight:800; color:var(--acc); font-size:18px; }
.req-info{ font-size:13px; margin:10px 0 8px; } .req-msg{ font-size:13px; color:var(--mut); font-style:italic; background:var(--card2); padding:10px; border-radius:10px; margin-bottom:10px; }
.req-act{ display:flex; gap:10px; } .req-act button{ flex:1; display:flex; align-items:center; justify-content:center; gap:6px; padding:11px; border-radius:11px; font-family:inherit; font-weight:700; font-size:14px; cursor:pointer; border:1px solid var(--line); } .decline{ background:var(--card2); color:var(--txt); } .approve{ background:var(--acc); color:#0c0f0c; border-color:var(--acc); }
.add-btn{ display:flex; align-items:center; gap:6px; background:var(--acc); color:#0c0f0c; border:none; padding:10px 15px; border-radius:12px; font-family:inherit; font-weight:700; font-size:13px; cursor:pointer; }
.mcar{ background:var(--card); border:1px solid var(--line); border-radius:18px; padding:14px; margin-bottom:14px; } .mcar.paused{ opacity:.6; } .mcar-art{ background:linear-gradient(135deg,#1b211c,#12150f); border-radius:12px; padding:10px; margin-bottom:12px; } .mcar-body{ cursor:pointer; }
.stat{ width:100%; margin-top:12px; display:flex; align-items:center; justify-content:center; gap:6px; background:var(--card2); border:1px solid var(--line); color:var(--mut); padding:10px; border-radius:11px; font-family:inherit; font-weight:600; font-size:13px; cursor:pointer; } .stat.on{ background:var(--accd); color:var(--acc); border-color:#3a4a18; }
.rate-edit{ display:flex; align-items:center; justify-content:space-between; gap:12px; } .rate-edit button{ width:46px; height:46px; border-radius:12px; background:var(--card2); border:1px solid var(--line); color:var(--acc); display:grid; place-items:center; cursor:pointer; font-family:inherit; font-size:20px; } .rate-big{ font-family:'Syne'; font-weight:800; font-size:26px; } .rate-big small{ color:var(--mut); font-size:13px; }
.legend{ display:flex; gap:14px; margin-bottom:10px; font-size:12px; color:var(--mut); flex-wrap:wrap; } .legend span{ display:flex; align-items:center; gap:6px; }
.lg{ width:12px; height:12px; border-radius:4px; display:inline-block; } .lg.avail{ background:var(--card2); border:1px solid var(--line); } .lg.blocked{ background:#3a2a2a; border:1px solid #5a3a3a; } .lg.booked{ background:var(--acc); } .lg.old{ background:var(--mut); border-radius:50%; } .lg.new{ background:var(--red); border-radius:50%; }
.acal{ display:grid; grid-template-columns:repeat(7,1fr); gap:5px; } .acd{ aspect-ratio:1; background:var(--card2); border:1px solid var(--line); border-radius:9px; color:var(--txt); display:flex; flex-direction:column; align-items:center; justify-content:center; cursor:pointer; font-family:inherit; } .acd span{ font-weight:700; font-size:14px; } .acd small{ font-size:8px; color:var(--mut); } .acd.blocked{ background:#3a2a2a; border-color:#5a3a3a; } .acd.blocked span{ color:var(--red); } .acd.booked{ background:var(--acc); border-color:var(--acc); color:#0c0f0c; cursor:default; } .acd.booked small{ color:#0c0f0c; }
.bline{ display:flex; align-items:center; gap:12px; background:var(--card); border:1px solid var(--line); border-radius:12px; padding:14px; margin-bottom:10px; } .bline.col{ flex-direction:column; align-items:stretch; gap:12px; } .bline-top{ display:flex; align-items:center; gap:12px; } .bline svg{ color:var(--acc); flex-shrink:0; } .tmini{ margin-left:auto; }
.inspect-cta{ display:flex; align-items:center; justify-content:center; gap:8px; background:var(--accd); border:1px solid #3a4a18; color:var(--acc); padding:11px; border-radius:11px; font-family:inherit; font-weight:700; font-size:13px; cursor:pointer; }
.danger{ width:100%; display:flex; align-items:center; justify-content:center; gap:8px; background:none; border:1px solid #4a2a2a; color:var(--red); padding:13px; border-radius:12px; font-family:inherit; font-weight:600; font-size:14px; cursor:pointer; margin-top:6px; }
.seg{ display:flex; gap:8px; padding:14px 16px 0; } .seg button{ flex:1; background:var(--card2); border:1px solid var(--line); color:var(--mut); padding:10px; border-radius:11px; font-family:inherit; font-size:12px; font-weight:600; cursor:pointer; } .seg button.on{ background:var(--acc); color:#0c0f0c; border-color:var(--acc); }
.balance{ background:linear-gradient(135deg,#1d2417,#141811); border:1px solid var(--line); border-radius:18px; padding:22px; text-align:center; margin-bottom:14px; display:flex; flex-direction:column; align-items:center; gap:8px; } .bal-v{ font-family:'Syne'; font-weight:800; font-size:38px; color:var(--acc); } .payout{ display:flex; align-items:center; gap:8px; background:var(--acc); color:#0c0f0c; border:none; padding:13px 24px; border-radius:13px; font-family:inherit; font-weight:700; font-size:14px; cursor:pointer; }
.tx{ display:flex; align-items:center; gap:12px; padding:12px 0; border-bottom:1px solid var(--line); } .tx:last-child{ border-bottom:none; } .tx-ic{ width:38px; height:38px; border-radius:11px; background:var(--accd); color:var(--acc); display:grid; place-items:center; } .tx-ic.out{ background:var(--card2); color:var(--mut); } .tx-i{ flex:1; } .tx-a{ font-family:'Syne'; font-weight:700; color:var(--acc); } .tx-a.out{ color:var(--mut); }
.add-art{ background:linear-gradient(135deg,#1b211c,#12150f); border-radius:14px; padding:14px; margin-bottom:14px; } .colors{ display:flex; gap:10px; margin-bottom:16px; justify-content:center; } .sw{ width:34px; height:34px; border-radius:50%; border:2px solid transparent; cursor:pointer; } .sw.on{ border-color:var(--acc); }
.photo-box{ display:flex; flex-direction:column; align-items:center; gap:8px; background:var(--card2); border:1px dashed var(--line); border-radius:14px; padding:26px; color:var(--mut); font-size:13px; } .photo-box svg{ color:var(--acc); }
.est{ background:var(--accd); border:1px solid #3a4a18; border-radius:14px; padding:16px; text-align:center; } .est-v{ font-family:'Syne'; font-weight:800; font-size:26px; color:var(--acc); margin-top:6px; }
.prof-top{ display:flex; align-items:center; gap:14px; margin-bottom:20px; } .prof-row{ width:100%; display:flex; align-items:center; gap:12px; background:var(--card); border:1px solid var(--line); border-radius:13px; padding:15px; margin-bottom:10px; font-family:inherit; color:var(--txt); font-size:14px; font-weight:600; cursor:pointer; } .prof-row svg{ color:var(--acc); } .verif{ background:var(--accd); color:var(--acc); font-size:11px; padding:3px 9px; border-radius:8px; }

/* inspection */
.pgrid{ display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; } .pslot{ position:relative; aspect-ratio:1; background:var(--card2); border:1px dashed var(--line); border-radius:13px; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; cursor:pointer; color:var(--mut); font-size:11px; overflow:hidden; } .pslot.filled{ border-style:solid; border-color:var(--acc); } .pslot svg{ color:var(--acc); } .pslot img{ position:absolute; inset:0; width:100%; height:100%; object-fit:cover; } .pck{ position:absolute; top:6px; right:6px; width:22px; height:22px; border-radius:50%; background:var(--acc); color:#0c0f0c; display:grid; place-items:center; }
.diagram{ position:relative; background:linear-gradient(135deg,#1b211c,#0e120d); border:1px solid var(--line); border-radius:18px; padding:12px; margin-bottom:12px; cursor:crosshair; } .cartop{ width:62%; max-width:200px; height:auto; display:block; margin:0 auto; }
.mark{ position:absolute; transform:translate(-50%,-50%); width:26px; height:26px; border-radius:50%; border:2px solid #0c0f0c; color:#0c0f0c; font-weight:800; font-size:12px; font-family:'Syne'; cursor:pointer; } .mark.new{ background:var(--red); } .mark.old{ background:var(--mut); }
.dleg{ display:flex; gap:18px; justify-content:center; margin-bottom:14px; font-size:12px; color:var(--mut); } .dleg span{ display:flex; align-items:center; gap:6px; }
.dlist{ display:flex; flex-direction:column; gap:8px; } .ditem{ display:flex; align-items:center; gap:10px; background:var(--card); border:1px solid var(--line); border-radius:12px; padding:12px; cursor:pointer; font-family:inherit; color:var(--txt); font-size:14px; } .dn{ width:24px; height:24px; border-radius:50%; display:grid; place-items:center; font-weight:800; font-size:12px; font-family:'Syne'; color:#0c0f0c; flex-shrink:0; } .dn.new{ background:var(--red); } .dn.old{ background:var(--mut); } .dcost{ font-family:'Syne'; font-weight:700; color:var(--warn); }
.exist{ display:flex; align-items:center; gap:8px; background:#2a230d; border:1px solid #4a3d12; color:var(--warn); font-size:12px; padding:10px; border-radius:10px; margin-bottom:14px; }
.field-l{ font-size:13px; color:var(--mut); margin:14px 0 8px; } .chips{ display:flex; gap:8px; flex-wrap:wrap; } .chip{ background:var(--card2); border:1px solid var(--line); color:var(--mut); padding:9px 14px; border-radius:10px; font-family:inherit; font-size:13px; font-weight:600; cursor:pointer; } .chip.on{ background:var(--acc); color:#0c0f0c; border-color:var(--acc); } .chip:disabled{ opacity:.4; }
.dphoto{ display:flex; align-items:center; justify-content:center; gap:8px; background:var(--card2); border:1px dashed var(--line); border-radius:12px; padding:16px; margin-top:14px; cursor:pointer; color:var(--txt); font-size:14px; overflow:hidden; } .dphoto svg{ color:var(--acc); } .dphoto img{ max-height:120px; border-radius:8px; }
.cost-row{ display:flex; justify-content:space-between; align-items:center; margin:14px 0; font-size:14px; } .cost-row b{ font-family:'Syne'; color:var(--warn); font-size:18px; }
.mhead{ display:flex; align-items:center; gap:9px; font-weight:600; font-size:14px; margin-bottom:14px; } .odo{ width:100%; background:var(--card2); border:1px solid var(--line); color:var(--acc); padding:14px; border-radius:12px; font-family:'Syne'; font-weight:800; font-size:24px; text-align:center; letter-spacing:3px; outline:none; }
.fbar{ display:flex; gap:5px; } .fseg{ flex:1; height:34px; background:var(--card2); border:1px solid var(--line); border-radius:7px; cursor:pointer; } .fseg.on{ background:var(--acc); border-color:var(--acc); } .flabels{ display:flex; justify-content:space-between; margin-top:8px; font-size:11px; color:var(--mut); } .flabels span:nth-child(2){ color:var(--acc); font-weight:700; }
.sum{ background:var(--card); border:1px solid var(--line); border-radius:14px; padding:16px; margin-bottom:16px; } .sum .row-between{ padding:7px 0; font-size:14px; }
.sign-wrap{ position:relative; background:var(--card2); border:1px solid var(--line); border-radius:14px; height:170px; overflow:hidden; } .sign{ width:100%; height:100%; display:block; touch-action:none; cursor:crosshair; } .sign-ph{ position:absolute; inset:0; display:flex; align-items:center; justify-content:center; gap:8px; color:var(--mut); font-size:14px; pointer-events:none; } .sign-clr{ position:absolute; top:10px; right:10px; width:32px; height:32px; border-radius:8px; background:var(--bg); border:1px solid var(--line); color:var(--mut); display:grid; place-items:center; cursor:pointer; }
.depres{ background:var(--card); border:1px solid var(--line); border-radius:16px; padding:16px; margin-top:20px; text-align:left; } .dr{ display:flex; justify-content:space-between; padding:9px 0; font-size:14px; } .dr.sub{ font-size:13px; color:var(--mut); padding:5px 0 5px 12px; } .dr.total{ border-top:1px solid var(--line); margin-top:6px; padding-top:13px; font-family:'Syne'; font-weight:800; font-size:17px; } .neg{ color:var(--warn); } .pos{ color:var(--acc); }

.modal-bg{ position:absolute; inset:0; background:rgba(0,0,0,.6); backdrop-filter:blur(4px); display:flex; align-items:flex-end; z-index:50; } .modal{ width:100%; background:var(--card); border-top-left-radius:24px; border-top-right-radius:24px; padding:20px; border-top:1px solid var(--line); max-height:90%; overflow-y:auto; animation:rise .3s ease; } .modal.danger{ border-top:2px solid var(--red); } @keyframes rise{ from{transform:translateY(20px)} to{transform:translateY(0)} }
.modal-head{ display:flex; align-items:center; justify-content:space-between; margin-bottom:14px; font-weight:700; font-size:16px; } .modal-head button{ background:var(--card2); border:1px solid var(--line); color:var(--txt); width:32px; height:32px; border-radius:50%; display:grid; place-items:center; cursor:pointer; }

.tabbar{ display:flex; background:var(--card); border-top:1px solid var(--line); } .tabbar button{ position:relative; flex:1; display:flex; flex-direction:column; align-items:center; gap:4px; background:none; border:none; color:var(--mut); padding:11px 4px; font-family:inherit; font-size:11px; font-weight:600; cursor:pointer; } .tabbar button.on{ color:var(--acc); } .tbadge{ position:absolute; top:5px; right:50%; transform:translateX(16px); background:var(--acc); color:#0c0f0c; font-size:10px; font-weight:800; width:16px; height:16px; border-radius:50%; display:grid; place-items:center; }

/* --- მიკრო-ანიმაციები და გადასვლები --- */
@keyframes fadeUp{ from{opacity:0; transform:translateY(12px)} to{opacity:1; transform:translateY(0)} }
@keyframes popIn{ 0%{opacity:0; transform:scale(.7)} 60%{transform:scale(1.06)} 100%{opacity:1; transform:scale(1)} }
@keyframes growBar{ from{transform:scaleY(0)} to{transform:scaleY(1)} }
@keyframes navpop{ 0%{transform:scale(1)} 45%{transform:scale(1.28)} 100%{transform:scale(1)} }
@keyframes ring{ 0%{box-shadow:0 0 0 0 rgba(200,255,46,.5)} 100%{box-shadow:0 0 0 18px rgba(200,255,46,0)} }
.ccard,.block,.kpi,.mcar,.bline,.spec,.opt,.balance,.req,.prof-row,.ditem{ animation:fadeUp .4s both; }
.detail-hero{ animation:fadeUp .35s both; }
.step-name{ animation:fadeUp .3s both; }
.done-ic{ animation:popIn .55s cubic-bezier(.2,1.3,.4,1) both, ring 1s ease .35s; }
.mark.new{ animation:popIn .3s cubic-bezier(.2,1.3,.4,1); }
.fav.on{ animation:popIn .3s; }
.tabbar button.on svg{ animation:navpop .35s ease; }
.mode-switch button{ transition:background .2s, color .2s; }
.ccard,.opt,.fchip,.chip,.prof-row,.bline,.mcar-body,.dates-row,.searchbox-lg{ transition:transform .12s ease; }
.ccard:active,.opt:active,.fchip:active,.chip:active,.prof-row:active,.bline:active,.mcar-body:active{ transform:scale(.985); }
.fab,.add-btn,.payout,.inspect-cta{ transition:transform .12s ease; }
.fab:active,.add-btn:active,.payout:active,.inspect-cta:active,.dates-row:active,.searchbox-lg:active{ transform:scale(.96); }
.cd,.acd{ transition:transform .1s ease; } .cd:active,.acd:active{ transform:scale(.9); }
/* --- დეტალური გვერდის გაუმჯობესება --- */
.qchips{ display:flex; gap:8px; margin-top:8px; flex-wrap:wrap; }
.qchip{ display:flex; align-items:center; gap:4px; background:var(--card2); border:1px solid var(--line); color:var(--txt); font-size:12px; padding:5px 10px; border-radius:9px; } .qchip svg{ color:var(--acc); }
.section-t{ font-size:15px; font-weight:700; margin:20px 0 12px; }
.hgrow{ flex:1; } .hgrow .mut{ display:flex; align-items:center; gap:5px; margin-top:3px; }
.msg-btn{ width:42px; height:42px; border-radius:50%; background:var(--bg); border:1px solid var(--line); color:var(--acc); display:grid; place-items:center; cursor:pointer; flex-shrink:0; transition:transform .12s ease; } .msg-btn:active{ transform:scale(.94); }
.minimap{ height:130px; border-radius:14px; overflow:hidden; border:1px solid var(--line); }
.loc-row{ display:flex; align-items:center; gap:8px; font-size:14px; margin-top:10px; }
.rev-head{ display:flex; gap:18px; align-items:center; background:var(--card); border:1px solid var(--line); border-radius:14px; padding:16px; margin-bottom:12px; }
.rev-score{ text-align:center; flex-shrink:0; } .rev-num{ font-family:'Syne'; font-weight:800; font-size:34px; line-height:1; } .rev-stars{ display:flex; gap:2px; justify-content:center; margin:5px 0; }
.rbars{ flex:1; display:flex; flex-direction:column; gap:5px; }
.rbar{ display:flex; align-items:center; gap:8px; font-size:11px; color:var(--mut); } .rtrack{ flex:1; height:6px; background:var(--card2); border-radius:3px; overflow:hidden; } .rfill{ height:100%; background:var(--acc); border-radius:3px; }
.rev{ background:var(--card); border:1px solid var(--line); border-radius:14px; padding:14px; margin-bottom:10px; }
.rev-top{ display:flex; align-items:center; gap:10px; margin-bottom:8px; } .rev-av{ width:34px; height:34px; border-radius:50%; background:var(--card2); border:1px solid var(--line); display:grid; place-items:center; font-weight:700; } .rev-rs{ display:flex; gap:1px; margin-left:auto; } .rev-text{ font-size:13px; color:var(--txt); line-height:1.5; }
.sim-scroll{ display:flex; gap:12px; overflow-x:auto; padding-bottom:6px; }
.sim{ flex-shrink:0; width:144px; background:var(--card); border:1px solid var(--line); border-radius:14px; padding:10px; cursor:pointer; font-family:inherit; color:var(--txt); text-align:left; transition:transform .12s ease; } .sim:active{ transform:scale(.97); }
.sim-art{ background:linear-gradient(135deg,#1b211c,#12150f); border-radius:10px; padding:8px; margin-bottom:8px; } .sim-n{ font-weight:700; font-size:13px; } .sim-p{ font-family:'Syne'; font-weight:800; color:var(--acc); font-size:14px; margin-top:2px; } .sim-p small{ color:var(--mut); font-size:10px; }

@media (prefers-reduced-motion: reduce){ *{ animation:none !important; transition:none !important; } }
`;
