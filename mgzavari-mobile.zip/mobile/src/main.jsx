import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import "./mobile.css";

/* ნატიური მორგება — მუშაობს მხოლოდ მოწყობილობაზე, ვებზე უსაფრთხოდ გამოტოვდება */
async function initNative() {
  try {
    const { Capacitor } = await import("@capacitor/core");
    if (!Capacitor.isNativePlatform()) return;
    const { StatusBar, Style } = await import("@capacitor/status-bar");
    await StatusBar.setStyle({ style: Style.Dark });
    await StatusBar.setBackgroundColor({ color: "#0c0f0c" });
    const { SplashScreen } = await import("@capacitor/splash-screen");
    await SplashScreen.hide();
  } catch (e) {
    /* ვებ-რეჟიმი — საჭირო არ არის */
  }
}
initNative();

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
