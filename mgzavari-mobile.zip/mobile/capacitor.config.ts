import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "ge.mgzavari.rent",
  appName: "MGZAVARI Rent",
  webDir: "dist",
  backgroundColor: "#0c0f0c",
  plugins: {
    SplashScreen: {
      backgroundColor: "#0c0f0c",
      showSpinner: false,
      launchAutoHide: true,
    },
    StatusBar: {
      style: "DARK",
      backgroundColor: "#0c0f0c",
    },
  },
};

export default config;
